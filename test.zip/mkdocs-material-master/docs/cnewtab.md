## 社區發文
!!! note    請勿連續亂發溫以免被ban


1.在[首頁](https://community.ssangyongsports.eu.org/)點擊[發文](https://community.ssangyongsports.eu.org/composer)

2.填寫標題

3.填寫貼文

4.點選分類:選擇棒球...類型

5.發布

[![](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEgXxTOmTIGddOyEp31ylOvpDlLOsdgFbrsPO6s2Qh65RThDWVcPnT5A-yOR7159n3EMJ27szV8ctaSdQEod5Ny80RY9479HndLsfpEzz8QTaoqmCIFNFkd4xOy4hrFoS9wjBDOeG-AlvWPi0shbPzUtzfsbtC7Ea6NHjEVk9y4kfppVFaZyHp_aTA/w640-h218/%E5%A1%AB%E5%AF%AB%E6%A8%99%E9%A1%8C%20(1).jpg)](https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEgXxTOmTIGddOyEp31ylOvpDlLOsdgFbrsPO6s2Qh65RThDWVcPnT5A-yOR7159n3EMJ27szV8ctaSdQEod5Ny80RY9479HndLsfpEzz8QTaoqmCIFNFkd4xOy4hrFoS9wjBDOeG-AlvWPi0shbPzUtzfsbtC7Ea6NHjEVk9y4kfppVFaZyHp_aTA/s1357/%E5%A1%AB%E5%AF%AB%E6%A8%99%E9%A1%8C%20(1).jpg)
