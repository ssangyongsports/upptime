# 如何查詢工單狀態
如果您是使用聯繫表單聯絡我們請點此：https://ssport.cf/T

如果您是使用電子郵件聯絡我們請點此：https://ssport.cf/S
# 教學
#### 1.打開我們向你傳送的聯繫通知Mail
![](https://i.imgur.com/ZjzxGqg.png)
## 2.複製工單ID
![](https://i.imgur.com/L6CzPWE_d.webp?maxwidth=760&fidelity=grand)
## 3.打開工單查詢表單
    如果您是使用聯繫表單聯絡我們請點此：https://ssport.cf/T
    如果您是使用電子郵件聯絡我們請點此：https://ssport.cf/S
## 4.填寫即可完成
![](https://i.imgur.com/X3kVtu3.png)
